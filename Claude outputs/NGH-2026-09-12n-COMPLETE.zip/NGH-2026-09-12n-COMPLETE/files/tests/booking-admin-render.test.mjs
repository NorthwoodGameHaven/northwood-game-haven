// NGH-BUILD 2026-09-12n
// tests/booking-admin-render.test.mjs — the Guru console request list.
//
// Reported from the shop: the Rejected tab highlighted, the tab itself saying
// "Rejected (20)", and the panel underneath saying "No pending requests." —
// twenty bookings the Guru could see the count of and not reach.
//
// The cause was `el.innerHTML = list.map(reqCardHtml).join("")`. One booking
// that throws takes the exception out of renderAdmin BEFORE innerHTML is
// assigned, so the panel silently keeps whatever the previous tab rendered.
// On a fresh console that is the default Pending tab's empty state — hence a
// pending message under a rejected tab.
//
// These tests pull the REAL function text out of site/booking.html and run it,
// so they test the shipped code rather than a copy of it that can drift.
import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const HTML = fs.readFileSync(path.join(ROOT, 'site', 'booking.html'), 'utf8');

// Pull one top-level `function name(...){...}` out of the page by brace
// counting. Naive brace counting would trip over braces inside strings, so
// this walks the source tracking quotes, template literals and comments.
function extractFunction(src, name) {
  let start = src.indexOf('function ' + name + '(');
  assert.notEqual(start, -1, 'could not find function ' + name + ' in booking.html');
  // Keep an `async` prefix. Slicing from `function` alone strips it, and the
  // extracted body then fails to parse the moment it contains `await` — which
  // silently looks like "the page is broken" rather than "the test is".
  const before = src.slice(Math.max(0, start - 10), start);
  const m = /(async\s+)$/.exec(before);
  if (m) start -= m[1].length;
  let i = src.indexOf('{', start), depth = 0;
  let str = null, esc = false, line = false, block = false;
  for (; i < src.length; i++) {
    const c = src[i], n = src[i + 1];
    if (line) { if (c === '\n') line = false; continue; }
    if (block) { if (c === '*' && n === '/') { block = false; i++; } continue; }
    if (str) {
      if (esc) { esc = false; continue; }
      if (c === '\\') { esc = true; continue; }
      if (c === str) str = null;
      continue;
    }
    if (c === '/' && n === '/') { line = true; i++; continue; }
    if (c === '/' && n === '*') { block = true; i++; continue; }
    if (c === '"' || c === "'" || c === '`') { str = c; continue; }
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  throw new Error('unbalanced braces reading ' + name);
}

const renderAdminSrc = extractFunction(HTML, 'renderAdmin');
const autoCancelSrc = extractFunction(HTML, 'autoCancelUnpaid');
const approveSrc = extractFunction(HTML, 'approve');

// ---- a sandbox with just enough of the page to run those two --------------
function makeSandbox(bookings, opts = {}) {
  const el = { innerHTML: '' };
  const tabsEl = { innerHTML: '' };
  const logged = { errors: [], warns: [] };
  const sb = {
    cache: { bookings },
    adminFilter: 'pending',
    $: (id) => (id === 'requests-list' ? el : id === 'admin-tabs' ? tabsEl : null),
    esc: (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    reqCardHtml: opts.reqCardHtml || ((r) => '<div class="card" data-id="' + r.id + '">' + r.id + '</div>'),
    renderAdminTabs: function () {
      const counts = { all: 0, pending: 0, approved: 0, hold: 0, rejected: 0 };
      sb.cache.bookings.forEach(r => { counts.all++; counts[r.status] = (counts[r.status] || 0) + 1; });
      tabsEl.innerHTML = JSON.stringify(counts);
    },
    console: {
      error: (...a) => logged.errors.push(a.join(' ')),
      warn: (...a) => logged.warns.push(a.join(' ')),
      log: () => { }
    },
    // autoCancelUnpaid dependencies
    feeIsPaid: (r) => !!r.feePaid,
    depIsPaid: (r) => !!r.depositPaid,
    refreshCache: async () => { },
    // approve() dependencies. The conflict scan is stubbed clean so the
    // confirm() gauntlet never fires — this test is about what approve WRITES.
    getReq: (id) => bookings.find(b => b.id === id) || null,
    bookingConflictScan: () => ({ red: [], tight: [] }),
    roomName: (x) => String(x),
    _evById: () => null,
    confirm: () => true,
    resendApproval: async () => { },
    renderAdmin: () => { },
    Store: {
      updated: [],
      async updateBooking(id, patch) { sb.Store.updated.push({ id, patch }); Object.assign(bookings.find(b => b.id === id), patch); },
      async sendEmail(to, subj) { sb.Store.sent.push({ to, subj }); },
      sent: []
    }
  };
  sb.Store.sent = [];
  vm.createContext(sb);
  vm.runInContext(renderAdminSrc + '\n' + autoCancelSrc + '\n' + approveSrc, sb);
  return { sb, el, tabsEl, logged };
}

const bk = (id, status, over = {}) => ({ id, status, name: 'Guest ' + id, date: '2026-09-01', ...over });

// ---------------------------------------------------------------------------
describe('the Rejected tab actually shows rejected bookings', () => {
  test('twenty rejected bookings render twenty cards', () => {
    const list = Array.from({ length: 20 }, (_, i) => bk('BK-' + i, 'rejected'));
    const { sb, el } = makeSandbox(list.concat([bk('A1', 'approved'), bk('A2', 'approved')]));
    sb.renderAdmin('rejected');
    assert.equal((el.innerHTML.match(/data-id=/g) || []).length, 20);
    assert.ok(!/No pending requests/.test(el.innerHTML));
  });

  test('the empty state names the tab you are actually on', () => {
    const { sb, el } = makeSandbox([bk('A1', 'approved')]);
    sb.renderAdmin('rejected');
    assert.match(el.innerHTML, /No rejected requests/);
    sb.renderAdmin('hold');
    assert.match(el.innerHTML, /No hold requests/);
  });
});

describe('one malformed booking cannot blank the tab', () => {
  // This is the regression. Before the fix, a single throwing record meant
  // innerHTML was never assigned and the panel kept the PREVIOUS tab's content.
  const throwOn = (badId) => (r) => {
    if (r.id === badId) throw new TypeError("Cannot read properties of undefined (reading 'map')");
    return '<div class="card" data-id="' + r.id + '">' + r.id + '</div>';
  };

  test('the other nineteen still render', () => {
    const list = Array.from({ length: 20 }, (_, i) => bk('BK-' + i, 'rejected'));
    const { sb, el } = makeSandbox(list, { reqCardHtml: throwOn('BK-7') });
    sb.renderAdmin('rejected');
    assert.equal((el.innerHTML.match(/data-id=/g) || []).length, 19);
  });

  test('the broken one is shown by id, not silently dropped', () => {
    const list = [bk('BK-1', 'rejected'), bk('BK-2', 'rejected', { name: 'Robyn' })];
    const { sb, el } = makeSandbox(list, { reqCardHtml: throwOn('BK-2') });
    sb.renderAdmin('rejected');
    assert.match(el.innerHTML, /BK-2/, 'the Guru must still be able to see which booking is broken');
    assert.match(el.innerHTML, /Robyn/, 'and who it belongs to');
    assert.match(el.innerHTML, /could not be displayed/);
  });

  test('the stale message from the previous tab is gone', () => {
    const list = [bk('BK-1', 'rejected')];
    const { sb, el } = makeSandbox(list, { reqCardHtml: throwOn('BK-1') });
    sb.renderAdmin('pending');                       // no pending -> empty state
    assert.match(el.innerHTML, /No pending requests/);
    sb.renderAdmin('rejected');                      // the reported situation
    assert.ok(!/No pending requests/.test(el.innerHTML),
      'the rejected tab must never still be showing the pending empty state');
  });

  test('the failure is reported to the console rather than swallowed', () => {
    const { sb, logged } = makeSandbox([bk('BK-1', 'rejected')], { reqCardHtml: throwOn('BK-1') });
    sb.renderAdmin('rejected');
    assert.ok(logged.errors.some(e => /BK-1/.test(e)), 'the failing id belongs in the console');
    assert.ok(logged.warns.some(w => /1 of 1/.test(w)));
  });

  test('every record throwing still leaves a usable page', () => {
    const list = Array.from({ length: 3 }, (_, i) => bk('BK-' + i, 'rejected'));
    const { sb, el } = makeSandbox(list, { reqCardHtml: () => { throw new Error('boom'); } });
    sb.renderAdmin('rejected');
    assert.equal((el.innerHTML.match(/could not be displayed/g) || []).length, 3);
  });
});

// ---------------------------------------------------------------------------
describe('auto-cancel stops fighting the Guru', () => {
  // "Why is Robyn's booking for the Depths rejected AGAIN?" — because
  // autoCancelUnpaid re-cancelled any approved+unpaid booking whose deadline
  // had passed, with no floor. A booking in the past was permanently eligible,
  // so re-approving it flipped it back on the next refresh and emailed the
  // guest another cancellation.
  const past = '2026-09-01';                 // deadline long gone
  const future = '2099-01-01';

  test('a booking whose date has passed is left alone', async () => {
    const { sb } = makeSandbox([bk('BK-PAST', 'approved', { date: past, email: 'robyn@example.com' })]);
    const changed = await sb.autoCancelUnpaid();
    assert.equal(changed, false, 'cancelling a date that is already gone frees no room and confuses the guest');
    assert.equal(sb.Store.updated.length, 0);
    assert.equal(sb.Store.sent.length, 0, 'and must not send another cancellation email');
  });

  test('the exempt flag holds even for a booking still inside the window', async () => {
    // Isolates the flag from the date floor: today's date IS in the cancel
    // window, so only autoCancelExempt can be what saves it.
    const iso = new Date().toISOString().slice(0, 10);
    const b = bk('BK-R', 'approved', { date: iso, autoCanceled: true, autoCancelExempt: true, email: 'robyn@example.com' });
    const { sb } = makeSandbox([b]);
    assert.equal(await sb.autoCancelUnpaid(), false, 'a re-approved booking must not be cancelled again');
    assert.equal(b.status, 'approved');
    assert.equal(sb.Store.sent.length, 0, 'and the guest must not get a second cancellation email');
  });

  test('approve() sets the exemption when re-approving a rejected booking', async () => {
    // Drives the REAL approve(). Without this, removing the exemption from
    // approve() breaks nothing visible in a test and Robyn gets emailed twice.
    const iso = new Date().toISOString().slice(0, 10);
    const b = bk('BK-RE', 'rejected', { date: iso, autoCanceled: true, email: 'robyn@example.com' });
    const { sb } = makeSandbox([b]);
    await sb.approve('BK-RE');
    assert.equal(sb.Store.updated[0].patch.status, 'approved');
    assert.equal(sb.Store.updated[0].patch.autoCancelExempt, true,
      're-approving something the robot cancelled must exempt it');
    // and prove it sticks
    sb.Store.sent.length = 0;
    assert.equal(await sb.autoCancelUnpaid(), false);
    assert.equal(b.status, 'approved');
  });

  test('approve() on a fresh pending booking adds no exemption', async () => {
    // The exemption is for overruling the robot, not a blanket opt-out — a
    // normally approved booking must still auto-cancel if it goes unpaid.
    const iso = new Date().toISOString().slice(0, 10);
    const b = bk('BK-NEW', 'pending', { date: iso, email: 'x@example.com' });
    const { sb } = makeSandbox([b]);
    await sb.approve('BK-NEW');
    assert.equal(sb.Store.updated[0].patch.autoCancelExempt, undefined);
    assert.equal(await sb.autoCancelUnpaid(), true, 'still subject to auto-cancel');
  });

  test('an unpaid booking still in its window is cancelled, once', async () => {
    // Yesterday's deadline, today's booking: the case auto-cancel exists for.
    const today = new Date();
    const iso = today.toISOString().slice(0, 10);
    const { sb } = makeSandbox([bk('BK-NOW', 'approved', { date: iso, email: 'x@example.com' })]);
    const changed = await sb.autoCancelUnpaid();
    assert.equal(changed, true, 'a same-day unpaid booking should still be released');
    assert.equal(sb.Store.updated[0].patch.status, 'rejected');
    assert.equal(sb.Store.sent.length, 1);
  });

  test('a future booking is never touched', async () => {
    const { sb } = makeSandbox([bk('BK-F', 'approved', { date: future, email: 'x@example.com' })]);
    assert.equal(await sb.autoCancelUnpaid(), false);
  });

  test('a paid booking is never touched, past or present', async () => {
    const { sb } = makeSandbox([
      bk('BK-P1', 'approved', { date: past, feePaid: true }),
      bk('BK-P2', 'approved', { date: past, depositPaid: true })
    ]);
    assert.equal(await sb.autoCancelUnpaid(), false);
  });
});
