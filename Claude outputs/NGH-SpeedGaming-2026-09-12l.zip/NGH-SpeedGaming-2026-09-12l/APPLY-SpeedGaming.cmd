@echo off
REM ============================================================
REM  NGH-BUILD 2026-09-12l - Speed Gaming Meet-up
REM  Double-click this file. It finds itself, finds the repo,
REM  copies the new files in, wires netlify.toml, and waits so
REM  you can read what it did.
REM ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "REPO=%USERPROFILE%\Documents\GitHub\northwood-game-haven"
if not exist "%REPO%\netlify.toml" (
  echo.
  echo   Could not find the repo at:
  echo     %REPO%
  echo.
  set /p REPO="  Paste the full path to northwood-game-haven and press Enter: "
)
if not exist "%REPO%\netlify.toml" (
  echo.
  echo   [X] That folder has no netlify.toml - it is not the repo. Nothing changed.
  echo.
  pause
  exit /b 1
)

echo.
echo   Repo: %REPO%
echo.
echo   --- copying files ---------------------------------------
xcopy /E /I /Y /Q "%~dp0files\*" "%REPO%\" >nul
if errorlevel 1 (
  echo   [X] Copy failed. Nothing else was changed.
  pause
  exit /b 1
)
echo   [ok] new files copied
echo.
echo   --- wiring netlify.toml ---------------------------------
pushd "%REPO%"
node patches\patch-speedgaming-2026-09-12l.cjs
set RC=%ERRORLEVEL%
popd
if not "%RC%"=="0" (
  echo.
  echo   [X] The wiring step failed - see the message above.
  pause
  exit /b 1
)

echo.
echo   --- running the tests -----------------------------------
pushd "%REPO%"
node --test tests\speedgaming.test.mjs tests\speedgaming-api.test.mjs
popd

echo.
echo   =========================================================
echo    Done. Now commit and push:
echo.
echo      cd "%REPO%"
echo      git add -A
echo      git commit -m "Speed Gaming Meet-up (NGH-BUILD 2026-09-12l)"
echo      git push
echo.
echo    Then, once Netlify finishes deploying:
echo      Guru console : gamehaven.guru/speedgaming-guru
echo      TV           : gamehaven.guru/speedgaming-tv
echo      Players      : gamehaven.guru/speedgaming
echo   =========================================================
echo.
pause
