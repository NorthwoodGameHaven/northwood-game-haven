@echo off
REM ============================================================
REM  NGH-BUILD 2026-09-12l
REM  Speed Gaming Meet-up · Trivia in-app · Karaoke Name That Tune
REM  · Magic night board
REM
REM  Double-click this file. It finds the repo, copies the files in,
REM  wires netlify.toml, runs the tests, and waits so you can read it.
REM ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "REPO=%USERPROFILE%\Documents\GitHub\northwood-game-haven"
if not exist "%REPO%\netlify.toml" (
  echo.
  echo   Could not find the repo at:
  echo     %REPO%
  echo.
  set /p REPO="  Paste the full path to northwood-game-haven and press Enter: "
)
if not exist "%REPO%\netlify.toml" (
  echo.
  echo   [X] That folder has no netlify.toml - it is not the repo. Nothing changed.
  echo.
  pause
  exit /b 1
)

echo.
echo   Repo: %REPO%
echo.
echo   --- copying files ---------------------------------------
xcopy /E /I /Y /Q "%~dp0files\*" "%REPO%\" >nul
if errorlevel 1 (
  echo   [X] Copy failed. Nothing else was changed.
  pause
  exit /b 1
)
echo   [ok] files copied
echo.
echo   --- wiring netlify.toml ---------------------------------
pushd "%REPO%"
node patches\patch-2026-09-12l.cjs
set RC=%ERRORLEVEL%
popd
if not "%RC%"=="0" (
  echo.
  echo   [X] The wiring step failed - see above. Files were copied but
  echo       the routes are NOT in netlify.toml yet.
  pause
  exit /b 1
)

echo.
echo   --- running the tests -----------------------------------
pushd "%REPO%"
node --test tests\speedgaming.test.mjs tests\speedgaming-api.test.mjs
node --import ./tests/_register-karaoke.mjs --test tests\karaoke-nametune.test.mjs
popd

echo.
echo   =========================================================
echo    Done. Commit and push:
echo.
echo      cd "%REPO%"
echo      git add -A
echo      git commit -F COMMIT-MESSAGE.txt
echo      git push
echo.
echo    (COMMIT-MESSAGE.txt was copied to the repo root.)
echo.
echo    Once Netlify finishes deploying:
echo      Speed Gaming  guru: /speedgaming-guru   tv: /speedgaming-tv   players: /speedgaming
echo      Magic night   set it up at /mtg (sign in as Guru)   tv: /mtg-tv
echo      Karaoke       Name That Tune is in the host page, under the transport
echo      Trivia        open Trivia in the app and tap Join
echo   =========================================================
echo.
pause
