@echo off
REM  NGH-BUILD 2026-09-12m - Venue mode. Double-click me.
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "REPO=%USERPROFILE%\Documents\GitHub\northwood-game-haven"
if not exist "%REPO%\netlify.toml" (
  echo.
  echo   Could not find the repo at: %REPO%
  set /p REPO="  Paste the full path to northwood-game-haven: "
)
if not exist "%REPO%\netlify.toml" (
  echo.  & echo   [X] No netlify.toml there - not the repo. Nothing changed.
  echo.  & pause & exit /b 1
)
echo.
echo   Repo: %REPO%
echo.
echo   --- copying files ---------------------------------------
xcopy /E /I /Y /Q "%~dp0files\*" "%REPO%\" >nul
if errorlevel 1 ( echo   [X] Copy failed. & pause & exit /b 1 )
echo   [ok] files copied
echo.
echo   --- wiring netlify.toml ---------------------------------
pushd "%REPO%"
node patches\patch-venue-2026-09-12m.cjs
set RC=%ERRORLEVEL%
popd
if not "%RC%"=="0" ( echo. & echo   [X] Wiring failed - see above. & pause & exit /b 1 )
echo.
echo   --- running the tests -----------------------------------
pushd "%REPO%"
node --test tests\venue.test.mjs
popd
echo.
echo   =========================================================
echo    Done. Then:
echo      1. git add -A ^&^& git commit ^&^& git push
echo      2. Netlify: set VENUE_KEY, then Trigger deploy
echo      3. Point the Google TV Streamers at gamehaven.guru/tv-auto
echo.
echo    Companion + X32 setup: docs\NGH-VENUE-MODE.md
echo   =========================================================
echo.
pause
