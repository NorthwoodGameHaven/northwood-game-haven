@echo off
REM  NGH-BUILD 2026-09-12n - privacy policy, Android deploy prep, runbooks.
REM  Double-click me.
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "REPO=%USERPROFILE%\Documents\GitHub\northwood-game-haven"
if not exist "%REPO%\netlify.toml" (
  echo. & echo   Could not find the repo at: %REPO%
  set /p REPO="  Paste the full path to northwood-game-haven: "
)
if not exist "%REPO%\netlify.toml" (
  echo. & echo   [X] No netlify.toml there - not the repo. Nothing changed.
  echo. & pause & exit /b 1
)
echo. & echo   Repo: %REPO% & echo.
echo   --- copying files ---------------------------------------
xcopy /E /I /Y /Q "%~dp0files\*" "%REPO%\" >nul
if errorlevel 1 ( echo   [X] Copy failed. & pause & exit /b 1 )
echo   [ok] files copied
echo.
echo   --- wiring netlify.toml ---------------------------------
pushd "%REPO%"
node patches\patch-2026-09-12n.cjs
set RC=%ERRORLEVEL%
popd
if not "%RC%"=="0" ( echo. & echo   [X] Wiring failed - see above. & pause & exit /b 1 )
echo.
echo   --- running the whole test suite ------------------------
pushd "%REPO%"
node --test tests/*.test.mjs
popd
echo.
echo   =========================================================
echo    Done. Then:
echo      1. git add -A ^&^& commit ^&^& push
echo      2. Check https://gamehaven.guru/privacy loads
echo.
echo    READ THIS FIRST:  docs\START-HERE-2026-09-12.md
echo    Android:          docs\NGH-ANDROID-DEPLOY.md
echo    Shop rack PC:     docs\NGH-SHOP-SERVER-UPDATE.md
echo    Store graphics:   tools\store-assets\
echo   =========================================================
echo. & pause
